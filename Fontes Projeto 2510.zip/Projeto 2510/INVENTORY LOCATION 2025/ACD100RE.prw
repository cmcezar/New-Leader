#INCLUDE "TOTVS.CH" 


/*/{Protheus.doc} ACD100RE
Rotina de impress�o das ordens de separa��o
@type       user function
@author    TOTVS 
/*/
User Function ACD100RE()

Local cRet := 'NLACDR01'

Return( cRet )
