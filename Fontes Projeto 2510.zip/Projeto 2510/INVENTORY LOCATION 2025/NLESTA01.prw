#include 'protheus.ch'
#include 'parmtype.ch'

// -------------------------------------------- \\
/*/{Protheus.doc} NLESTA01()
// Cadstro para vicncular produto � um endere�o.
@author Claudio Macedo
@since 20/11/2025
@version 1.0
@type Function
/*/
// -------------------------------------------- \\
User Function NLESTA01()

Local aCores  := {{"U_GetSldBF(ZZ2->ZZ2_LOCAL, ZZ2->ZZ2_LOCALI, ZZ2->ZZ2_CODPRO) = 0", "BR_VERDE"},;
          		  {"U_GetSldBF(ZZ2->ZZ2_LOCAL, ZZ2->ZZ2_LOCALI, ZZ2->ZZ2_CODPRO) > 0" , "BR_VERMELHO"}}

Private cCadastro := 'Endere�o x Produto'         
                                                                
Private aRotina := {{'Visualizar', 'AxVisual', 0, 2},;
                    {'Incluir'   , 'AxInclui', 0, 3},;
                    {'Excluir'   , 'U_ESTA01A()', 0, 5},;
                    {'Legenda'   , 'LegPCP01', 0, 6}}

MBrowse(,,,,'ZZ2',,,,,2,aCores)

Return Nil

// -------------------------------------------- \\
/*/{Protheus.doc} LegPCP01()
// Legenda.
@author Claudio Macedo
@since 17/04/2019
@version 1.0
@type Function
/*/
// -------------------------------------------- \\
Static Function LegPCP01()

BrwLegenda('Legenda', '', {{'BR_VERDE'   , 'Vazio'},;
                           {'BR_VERMELHO', 'Ocupado'}})
Return .T.

// -------------------------------------------- \\
/*/{Protheus.doc} GetSldBF()
// Retorna o saldo do produto no endere�o e armaz�m
@author Claudio Macedo
@since 20/11/2025
@version 1.0
@type Function
/*/
// -------------------------------------------- \\
User Function GetSldBF(cLocal, cEnder, cProduto)

Local nSaldo := 0

SBF->(DbSetOrder(1))
If SBF->(DbSeek(xFilial('SBF') + cLocal + cEnder + cProduto)) .And. SBF->BF_QUANT > 0
    nSaldo := SBF->BF_QUANT
Endif 

Return nSaldo

// -------------------------------------------- \\
/*/{Protheus.doc} ESTA01A()
// Exclui o v�nculo do Endere�o x Produto, caso 
   n�o tenha saldo no endere�o.
@author Claudio Macedo
@since 20/11/2025
@version 1.0
@type Function
/*/
// -------------------------------------------- \\
User Function ESTA01A()

// Verifica se existe saldo do produto no endere�o
If  U_GetSldBF(ZZ2->ZZ2_LOCAL, ZZ2->ZZ2_LOCALI, ZZ2->ZZ2_CODPRO) = 0

    If MsgYesNo('Confirma a exclus�o do v�nculo do endere�o ' + Alltrim(ZZ2->ZZ2_LOCALI) +;
                ' com o produto '+ Alltrim(ZZ2->ZZ2_CODPRO) + ' ?')
    
        ZZ2->(reclock('ZZ2', .F.))
        ZZ2->(DbDelete())
        ZZ2->(MsUnlock())
        
        MsgInfo('V�nculo do endere�o x produto exclu�do !')

    Endif 
 
Else
    Alert('N�o foi poss�vel excluir o v�nculo, pois existe saldo do produto no endere�o. ')
Endif 

Return Nil
